<footer class="sticky-footer bg-white">
	<div class="container my-auto">
		<div class="copyright text-center my-auto">
			<span>Copyright &copy; Trupressed and Developed By <a href="https://proglabs.co" target="_blank">Proglabs</a> </span>
		</div>
	</div>
</footer>