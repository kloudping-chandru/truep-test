  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>
  
<script src="https://www.gstatic.com/firebasejs/10.7.1/firebase-app.js" type="module"></script>

<!-- TODO: Add SDKs for Firebase products that you want to use
     https://firebase.google.com/docs/web/setup#available-libraries -->
<script src="https://www.gstatic.com/firebasejs/10.7.1/firebase-analytics.js" type="module"></script>
<script src="https://www.gstatic.com/firebasejs/10.7.1/firebase-functions.js" type="module"></script>
<script src="https://www.gstatic.com/firebasejs/10.7.1/firebase-database.js" type="module"></script>
<script src="https://www.gstatic.com/firebasejs/10.7.1/firebase-storage.js" type="module"></script>

<script src="https://www.gstatic.com/firebasejs/10.7.1/firebase-app-compat.js" type="module"></script>
<script src="https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore-compat.js" type="module"></script>
<script src="https://www.gstatic.com/firebasejs/10.7.1/firebase-auth-compat.js" type="module"></script>

<script src="js/firebasescript.js" type="module"></script>